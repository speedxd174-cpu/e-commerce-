import test from 'node:test';
import assert from 'node:assert/strict';
import {
  createAdminAuthService,
  hashAccessCode,
  signSessionToken,
  verifyAccessCodeHash,
  verifySessionToken,
} from './adminAuth';

test('hashAccessCode and verifyAccessCodeHash validate matching and mismatched codes', () => {
  const hash = hashAccessCode('wfg-2026-secret');
  assert.ok(hash.startsWith('scrypt$'));
  assert.equal(verifyAccessCodeHash('wfg-2026-secret', hash), true);
  assert.equal(verifyAccessCodeHash('wrong-code', hash), false);
});

test('first-run setup claims special code, locks setup, and verifies login', () => {
  const auth = createAdminAuthService({
    getEnvCode: () => '',
    sessionSecret: 'test-session-secret-key',
  });

  assert.deepEqual(auth.getStatus(), { mode: 'setup', configured: false });

  const shortClaim = auth.claimInitialCode('12');
  assert.equal(shortClaim.ok, false);

  const claimed = auth.claimInitialCode('butwal976');
  assert.equal(claimed.ok, true);
  if (!claimed.ok) return;

  assert.deepEqual(auth.getStatus(), { mode: 'claimed', configured: true });

  // Second setup attempt must be locked
  const secondClaim = auth.claimInitialCode('another-code');
  assert.equal(secondClaim.ok, false);
  if (!secondClaim.ok) {
    assert.equal(secondClaim.status, 409);
  }

  // Wrong code rejected, claimed code succeeds
  const badLogin = auth.login('wrong-code');
  assert.equal(badLogin.ok, false);

  const goodLogin = auth.login('butwal976');
  assert.equal(goodLogin.ok, true);
  if (!goodLogin.ok) return;

  const verified = auth.verifyBearerHeader(`Bearer ${goodLogin.token}`);
  assert.ok(verified);
  assert.equal(verified.role, 'admin');

  // Logout revokes token
  auth.revokeBearerHeader(`Bearer ${goodLogin.token}`);
  assert.equal(auth.verifyBearerHeader(`Bearer ${goodLogin.token}`), null);
});

test('configured environment ADMIN_ACCESS_CODE overrides claimed hash', () => {
  let envCode = '';
  const auth = createAdminAuthService({
    getEnvCode: () => envCode,
    sessionSecret: 'test-session-secret-key',
  });

  const claim = auth.claimInitialCode('local-claim-code');
  assert.equal(claim.ok, true);

  envCode = 'env-master-code';
  assert.deepEqual(auth.getStatus(), { mode: 'env', configured: true });
  assert.equal(auth.login('local-claim-code').ok, false);
  assert.equal(auth.login('env-master-code').ok, true);
});

test('verifySessionToken rejects tampered and expired tokens', () => {
  const { token } = signSessionToken('secret-1', 1000);
  assert.ok(verifySessionToken(token, 'secret-1', Date.now()));
  assert.equal(verifySessionToken(`${token}x`, 'secret-1', Date.now()), null);
  assert.equal(verifySessionToken(token, 'secret-1', Date.now() + 5000), null);
});
