import { SEED_ORDERS, SEED_PRODUCTS } from '../data/seedProducts';
import { Order, OrderStatus, Product, StoreRepository } from '../types/store';

const PRODUCTS_STORAGE_KEY = 'wf_galaxy_products_v1';
const ORDERS_STORAGE_KEY = 'wf_galaxy_orders_v1';
const CART_STORAGE_KEY = 'wf_galaxy_cart_v1';

function normalizeProductImage(product: Product): Product {
  if (product.imageUrl && product.imageUrl.startsWith('/src/assets/images/')) {
    return {
      ...product,
      imageUrl: product.imageUrl.replace('/src/assets/images/', '/images/'),
    };
  }
  return product;
}

/**
 * Browser-local persistence adapter for the client demo.
 * Structured behind the StoreRepository interface so it can be swapped
 * cleanly with Supabase or Firebase Firestore in production.
 */
export class LocalStorageStoreRepository implements StoreRepository {
  getProducts(): Product[] {
    if (typeof window === 'undefined') return SEED_PRODUCTS;
    try {
      const raw = window.localStorage.getItem(PRODUCTS_STORAGE_KEY);
      if (!raw) {
        window.localStorage.setItem(PRODUCTS_STORAGE_KEY, JSON.stringify(SEED_PRODUCTS));
        return SEED_PRODUCTS;
      }
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) && parsed.length > 0
        ? parsed.map(normalizeProductImage)
        : SEED_PRODUCTS;
    } catch {
      return SEED_PRODUCTS;
    }
  }

  saveProducts(products: Product[]): void {
    if (typeof window === 'undefined') return;
    window.localStorage.setItem(PRODUCTS_STORAGE_KEY, JSON.stringify(products));
  }

  upsertProduct(product: Product): Product[] {
    const current = this.getProducts();
    const index = current.findIndex((item) => item.id === product.id);
    const updated =
      index >= 0
        ? current.map((item) => (item.id === product.id ? product : item))
        : [product, ...current];
    this.saveProducts(updated);
    return updated;
  }

  deleteProduct(productId: string): Product[] {
    const current = this.getProducts();
    const updated = current.filter((item) => item.id !== productId);
    this.saveProducts(updated);
    return updated;
  }

  getOrders(): Order[] {
    if (typeof window === 'undefined') return SEED_ORDERS;
    try {
      const raw = window.localStorage.getItem(ORDERS_STORAGE_KEY);
      if (!raw) {
        window.localStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify(SEED_ORDERS));
        return SEED_ORDERS;
      }
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : SEED_ORDERS;
    } catch {
      return SEED_ORDERS;
    }
  }

  createOrder(order: Order): Order[] {
    const current = this.getOrders();
    const updated = [order, ...current];
    if (typeof window !== 'undefined') {
      window.localStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify(updated));
    }
    return updated;
  }

  updateOrderStatus(orderId: string, status: OrderStatus): Order[] {
    const current = this.getOrders();
    const updated = current.map((order) =>
      order.id === orderId ? { ...order, status } : order,
    );
    if (typeof window !== 'undefined') {
      window.localStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify(updated));
    }
    return updated;
  }

  resetDemoData(): { products: Product[]; orders: Order[] } {
    if (typeof window !== 'undefined') {
      window.localStorage.setItem(PRODUCTS_STORAGE_KEY, JSON.stringify(SEED_PRODUCTS));
      window.localStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify(SEED_ORDERS));
    }
    return { products: SEED_PRODUCTS, orders: SEED_ORDERS };
  }
}

export const storeRepository: StoreRepository = new LocalStorageStoreRepository();

export function loadPersistedCart<T>(): T[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = window.localStorage.getItem(CART_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function savePersistedCart<T>(items: T[]): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(items));
  } catch {
    // Ignore storage quota issues gracefully
  }
}
