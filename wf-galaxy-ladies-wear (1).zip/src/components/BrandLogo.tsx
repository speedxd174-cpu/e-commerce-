import React, { useEffect, useState } from 'react';
import { Sparkles } from 'lucide-react';

export function BrandEmblem({ className = 'w-9 h-9' }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <circle cx="32" cy="32" r="30.5" fill="#FFFCFD" stroke="#EED5DE" strokeWidth="1.5" />
      <path
        d="M35.5 14.5C35.5 14.5 34.2 19 34 22C33.8 25 36.2 27.5 37.8 31.5C40.5 38.2 44.5 47.5 47 51C42.5 52.2 35.5 52.8 30 51.5C24.5 50.2 19 46.5 16.5 41.5C21.2 42.5 25.5 40.5 28.5 36.5C31.5 32.5 32.5 26 32.5 22C32.5 18.5 33.5 15 35.5 14.5Z"
        fill="#7A1C3A"
      />
      <path
        d="M34 22C31.5 27.5 28 36 22 44.5M35.5 25C36.5 33 38.5 42.5 42.5 49.5"
        stroke="#DFCFA8"
        strokeWidth="1.1"
        strokeLinecap="round"
        opacity="0.7"
      />
      <circle cx="35.2" cy="12" r="1.8" fill="#B89047" />
    </svg>
  );
}

interface ProductImageProps {
  src: string;
  alt: string;
  className?: string;
  label?: string;
}

export function ProductImage({ src, alt, className = '', label }: ProductImageProps) {
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    setFailed(false);
  }, [src]);

  if (failed || !src) {
    return (
      <div
        className={`flex flex-col items-center justify-center bg-gradient-to-br from-[#FBF4F6] via-[#F4E4EA] to-[#EADCE1] text-[#7A1C3A] p-6 text-center ${className}`}
        role="img"
        aria-label={alt}
      >
        <Sparkles className="w-7 h-7 mb-2 opacity-60" strokeWidth={1.5} />
        <span className="font-display text-lg font-semibold leading-snug">
          {label || 'WF Galaxy Ladies Wear'}
        </span>
        <span className="text-xs text-[#645359] mt-1">Butwal, Nepal</span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className={className}
    />
  );
}
