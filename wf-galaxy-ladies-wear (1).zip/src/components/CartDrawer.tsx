import React from 'react';
import { ArrowRight, Minus, Plus, ShoppingBag, Trash2, X } from 'lucide-react';
import { BUSINESS_INFO } from '../data/seedProducts';
import { CartItem } from '../types/store';
import { calculateCartTotals, formatNPR } from '../utils/commerce';
import { ProductImage } from './BrandLogo';

interface CartDrawerProps {
  isOpen: boolean;
  items: CartItem[];
  onClose: () => void;
  onUpdateQuantity: (key: string, delta: number) => void;
  onRemoveItem: (key: string) => void;
  onProceedToCheckout: () => void;
}

export function CartDrawer({
  isOpen,
  items,
  onClose,
  onUpdateQuantity,
  onRemoveItem,
  onProceedToCheckout,
}: CartDrawerProps) {
  if (!isOpen) return null;

  const totals = calculateCartTotals(items);

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-[#1F1619]/45 backdrop-blur-xs"
      role="dialog"
      aria-modal="true"
      aria-label="Shopping bag"
    >
      {/* Backdrop click closes drawer */}
      <div className="flex-1" onClick={onClose} aria-hidden="true" />

      <div className="w-full max-w-md bg-[#FFFCFD] h-full flex flex-col border-l border-[#EADCE1] shadow-2xl">
        {/* Drawer Header */}
        <div className="px-5 py-4 border-b border-[#EADCE1] flex items-center justify-between">
          <div>
            <h2 className="font-display text-2xl font-semibold text-[#1F1619]">
              Your Shopping Bag
            </h2>
            <p className="text-xs text-[#645359] tabular-nums">
              {totals.itemCount} {totals.itemCount === 1 ? 'item' : 'items'} selected
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close shopping bag"
            className="w-10 h-10 inline-flex items-center justify-center rounded-md text-[#1F1619] hover:bg-[#FDF5F7] cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Free Delivery Progress */}
        {items.length > 0 && (
          <div className="px-5 py-2.5 bg-[#FDF5F7] border-b border-[#EADCE1] text-xs text-[#645359]">
            {totals.amountToFreeDelivery === 0 ? (
              <span className="text-[#7A1C3A] font-medium">
                You qualify for free delivery across Nepal.
              </span>
            ) : (
              <span>
                Add{' '}
                <strong className="text-[#7A1C3A] tabular-nums">
                  {formatNPR(totals.amountToFreeDelivery)}
                </strong>{' '}
                more for free delivery (otherwise {formatNPR(BUSINESS_INFO.standardDeliveryFeeNpr)}).
              </span>
            )}
          </div>
        )}

        {/* Item List */}
        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
          {items.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center py-12">
              <ShoppingBag className="w-10 h-10 text-[#7A1C3A]/40 mb-3" strokeWidth={1.5} />
              <p className="font-display text-2xl font-semibold text-[#1F1619]">
                Your bag is empty
              </p>
              <p className="text-sm text-[#645359] mt-1.5 max-w-xs">
                Browse our dresses, kurtas, tops, and party wear to start your order.
              </p>
              <button
                type="button"
                onClick={onClose}
                className="mt-5 px-5 py-2.5 rounded-md bg-[#7A1C3A] text-white text-xs font-medium hover:bg-[#5C122A] transition-colors cursor-pointer"
              >
                Continue Shopping
              </button>
            </div>
          ) : (
            items.map((item) => (
              <div
                key={item.key}
                className="flex gap-3.5 pb-4 border-b border-[#EADCE1] last:border-b-0"
              >
                <div className="w-20 h-24 rounded-md overflow-hidden border border-[#EADCE1] bg-[#FDF5F7] shrink-0">
                  <ProductImage
                    src={item.imageUrl}
                    alt={item.name}
                    className="w-full h-full object-cover object-top"
                    label={item.name}
                  />
                </div>

                <div className="flex-1 min-w-0 flex flex-col justify-between">
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <h3 className="text-sm font-semibold text-[#1F1619] leading-snug truncate">
                        {item.name}
                      </h3>
                      <button
                        type="button"
                        onClick={() => onRemoveItem(item.key)}
                        aria-label={`Remove ${item.name} from bag`}
                        className="text-[#645359] hover:text-[#7A1C3A] p-1 cursor-pointer shrink-0"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                    <p className="text-xs text-[#645359] mt-0.5">
                      Size: {item.selectedSize} · Color: {item.selectedColor.name}
                    </p>
                  </div>

                  <div className="flex items-center justify-between gap-2 mt-3">
                    <div className="inline-flex items-center border border-[#EADCE1] rounded-md bg-white">
                      <button
                        type="button"
                        onClick={() => onUpdateQuantity(item.key, -1)}
                        aria-label={`Decrease quantity of ${item.name}`}
                        className="w-8 h-8 inline-flex items-center justify-center text-[#1F1619] hover:bg-[#FDF5F7] cursor-pointer"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="w-8 text-center text-xs font-medium tabular-nums">
                        {item.quantity}
                      </span>
                      <button
                        type="button"
                        onClick={() => onUpdateQuantity(item.key, 1)}
                        aria-label={`Increase quantity of ${item.name}`}
                        className="w-8 h-8 inline-flex items-center justify-center text-[#1F1619] hover:bg-[#FDF5F7] cursor-pointer"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>

                    <span className="text-sm font-semibold text-[#1F1619] tabular-nums">
                      {formatNPR(item.priceNpr * item.quantity)}
                    </span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Drawer Footer Totals */}
        {items.length > 0 && (
          <div className="px-5 py-4 border-t border-[#EADCE1] bg-[#FDF5F7] space-y-3">
            <div className="space-y-1.5 text-sm">
              <div className="flex justify-between text-[#645359]">
                <span>Subtotal</span>
                <span className="tabular-nums text-[#1F1619] font-medium">
                  {formatNPR(totals.subtotalNpr)}
                </span>
              </div>
              <div className="flex justify-between text-[#645359]">
                <span>Delivery across Nepal</span>
                <span className="tabular-nums text-[#1F1619] font-medium">
                  {totals.deliveryFeeNpr === 0 ? 'Free' : formatNPR(totals.deliveryFeeNpr)}
                </span>
              </div>
              <div className="flex justify-between text-base font-semibold text-[#1F1619] pt-2 border-t border-[#EADCE1]">
                <span>Total</span>
                <span className="tabular-nums text-[#7A1C3A]">
                  {formatNPR(totals.totalNpr)}
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={onProceedToCheckout}
              className="w-full inline-flex items-center justify-center gap-2 px-5 py-3.5 rounded-md bg-[#7A1C3A] hover:bg-[#5C122A] text-white text-sm font-medium transition-colors cursor-pointer"
            >
              <span>Proceed to Checkout</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
