import React, { useEffect, useState } from 'react';
import { ArrowLeft, MessageCircle, Minus, Plus, ShoppingBag, Truck, X } from 'lucide-react';
import { BUSINESS_INFO } from '../data/seedProducts';
import { Product, ProductColor } from '../types/store';
import { buildProductInquiryMessage, buildWhatsAppUrl, formatNPR } from '../utils/commerce';
import { ProductImage } from './BrandLogo';

interface ProductDetailViewProps {
  product: Product;
  isModal?: boolean;
  onClose?: () => void;
  onAddToCart: (product: Product, size: string, color: ProductColor, quantity: number) => void;
}

export function ProductDetailView({
  product,
  isModal = false,
  onClose,
  onAddToCart,
}: ProductDetailViewProps) {
  const [selectedSize, setSelectedSize] = useState<string>(product.sizes[0] || 'M');
  const [selectedColor, setSelectedColor] = useState<ProductColor>(
    product.colors[0] || { name: 'Default', hex: '#7A1C3A' },
  );
  const [quantity, setQuantity] = useState<number>(1);

  useEffect(() => {
    setSelectedSize(product.sizes[0] || 'M');
    setSelectedColor(product.colors[0] || { name: 'Default', hex: '#7A1C3A' });
    setQuantity(1);
  }, [product]);

  const whatsappUrl = buildWhatsAppUrl(
    buildProductInquiryMessage(product, selectedSize, selectedColor.name),
  );

  const content = (
    <div className="grid grid-cols-1 md:grid-cols-12 gap-8 lg:gap-10 items-start">
      {/* Left: Editorial Product Image */}
      <div className="md:col-span-6">
        <div className="aspect-[3/4] rounded-lg overflow-hidden border border-[#EADCE1] bg-[#FDF5F7]">
          <ProductImage
            src={product.imageUrl}
            alt={product.imageAlt}
            className="w-full h-full object-cover object-top"
            label={product.name}
          />
        </div>
      </div>

      {/* Right: Contiguous Purchase Module */}
      <div className="md:col-span-6 space-y-6">
        <div>
          <div className="flex items-center gap-2 text-xs text-[#645359]">
            <span>{product.category}</span>
            <span aria-hidden="true">·</span>
            <span>{product.inStock ? 'In Stock · Ready to Ship' : 'Made to Order'}</span>
          </div>
          <h1 className="font-display text-3xl sm:text-4xl font-semibold text-[#1F1619] mt-2 leading-tight">
            {product.name}
          </h1>
          <p className="mt-2.5 text-xl font-semibold text-[#7A1C3A] tabular-nums">
            {formatNPR(product.priceNpr)}
          </p>
          <p className="mt-1 text-xs text-[#645359]">
            Sample placeholder pricing · Cash on delivery &amp; WhatsApp ordering available
          </p>
        </div>

        <p className="text-sm text-[#1F1619]/85 leading-relaxed">{product.description}</p>

        {/* Size Selector */}
        <div>
          <div className="flex items-center justify-between text-xs mb-2">
            <span className="font-semibold text-[#1F1619]">Select Size</span>
            <span className="text-[#645359]">Selected: {selectedSize}</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {product.sizes.map((size) => {
              const active = selectedSize === size;
              return (
                <button
                  key={size}
                  type="button"
                  onClick={() => setSelectedSize(size)}
                  aria-pressed={active}
                  className={`min-w-[48px] px-3.5 py-2 rounded-md text-xs font-medium border transition-colors cursor-pointer ${
                    active
                      ? 'bg-[#7A1C3A] border-[#7A1C3A] text-white'
                      : 'bg-white border-[#EADCE1] text-[#1F1619] hover:border-[#7A1C3A]'
                  }`}
                >
                  {size}
                </button>
              );
            })}
          </div>
        </div>

        {/* Color Selector */}
        <div>
          <div className="flex items-center justify-between text-xs mb-2">
            <span className="font-semibold text-[#1F1619]">Select Color</span>
            <span className="text-[#645359]">{selectedColor.name}</span>
          </div>
          <div className="flex flex-wrap gap-2.5">
            {product.colors.map((color) => {
              const active = selectedColor.name === color.name;
              return (
                <button
                  key={color.name}
                  type="button"
                  onClick={() => setSelectedColor(color)}
                  aria-pressed={active}
                  className={`inline-flex items-center gap-2 px-3 py-2 rounded-md text-xs font-medium border transition-colors cursor-pointer ${
                    active
                      ? 'border-[#7A1C3A] bg-[#FDF5F7] text-[#7A1C3A]'
                      : 'border-[#EADCE1] bg-white text-[#1F1619] hover:border-[#7A1C3A]/50'
                  }`}
                >
                  <span
                    className="w-3.5 h-3.5 rounded-full border border-black/15 shrink-0"
                    style={{ backgroundColor: color.hex }}
                  />
                  <span>{color.name}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Quantity Stepper */}
        <div className="flex items-center gap-4">
          <span className="text-xs font-semibold text-[#1F1619]">Quantity</span>
          <div className="inline-flex items-center border border-[#EADCE1] rounded-md bg-white">
            <button
              type="button"
              onClick={() => setQuantity((q) => Math.max(1, q - 1))}
              aria-label="Decrease quantity"
              className="w-10 h-10 inline-flex items-center justify-center text-[#1F1619] hover:bg-[#FDF5F7] cursor-pointer"
            >
              <Minus className="w-3.5 h-3.5" />
            </button>
            <span className="w-10 text-center text-sm font-medium tabular-nums">{quantity}</span>
            <button
              type="button"
              onClick={() => setQuantity((q) => q + 1)}
              aria-label="Increase quantity"
              className="w-10 h-10 inline-flex items-center justify-center text-[#1F1619] hover:bg-[#FDF5F7] cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Purchase Actions */}
        <div className="space-y-3 pt-2">
          <button
            type="button"
            onClick={() => {
              onAddToCart(product, selectedSize, selectedColor, quantity);
              if (isModal && onClose) onClose();
            }}
            className="w-full inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-md bg-[#7A1C3A] hover:bg-[#5C122A] text-white text-sm font-medium transition-colors cursor-pointer"
          >
            <ShoppingBag className="w-4 h-4" />
            <span>
              Add to Cart · {formatNPR(product.priceNpr * quantity)}
            </span>
          </button>

          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full inline-flex items-center justify-center gap-2 px-6 py-3 rounded-md border border-[#1F1619]/20 bg-white hover:border-[#7A1C3A] hover:text-[#7A1C3A] text-[#1F1619] text-sm font-medium transition-colors"
          >
            <MessageCircle className="w-4 h-4" />
            <span>Inquire or Order on WhatsApp</span>
          </a>
        </div>

        {/* Fabric & Delivery Details */}
        <div className="pt-4 border-t border-[#EADCE1] space-y-2 text-xs text-[#645359]">
          <p>
            <strong className="text-[#1F1619]">Fabric &amp; Care:</strong> {product.fabricCare}
          </p>
          <p className="inline-flex items-center gap-1.5">
            <Truck className="w-3.5 h-3.5 text-[#7A1C3A]" />
            <span>
              {BUSINESS_INFO.deliveryNote} · Dispatched from {BUSINESS_INFO.location}
            </span>
          </p>
        </div>
      </div>
    </div>
  );

  if (isModal) {
    return (
      <div
        className="fixed inset-0 z-50 bg-[#1F1619]/50 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
        role="dialog"
        aria-modal="true"
        aria-label={`Product details for ${product.name}`}
      >
        <div className="relative bg-[#FFFCFD] border border-[#EADCE1] rounded-lg max-w-4xl w-full max-h-[92vh] overflow-y-auto p-5 sm:p-8 shadow-xl">
          <button
            type="button"
            onClick={onClose}
            aria-label="Close product quick view"
            className="absolute top-4 right-4 w-10 h-10 inline-flex items-center justify-center rounded-md bg-[#FDF5F7] text-[#1F1619] hover:bg-[#F8E8EE] cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
          {content}
        </div>
      </div>
    );
  }

  return (
    <main className="max-w-[1200px] mx-auto px-4 sm:px-6 py-10 sm:py-14">
      {onClose && (
        <button
          type="button"
          onClick={onClose}
          className="inline-flex items-center gap-2 text-sm font-medium text-[#645359] hover:text-[#7A1C3A] mb-6 cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Collection</span>
        </button>
      )}
      {content}
    </main>
  );
}
