import React, { useState } from 'react';
import { Menu, Search, ShoppingBag, X } from 'lucide-react';
import { BUSINESS_INFO } from '../data/seedProducts';
import { BrandEmblem } from './BrandLogo';

export type AppRoute =
  | { name: 'home' }
  | { name: 'shop' }
  | { name: 'new-arrivals' }
  | { name: 'collections' }
  | { name: 'contact' }
  | { name: 'product'; productId: string }
  | { name: 'checkout' }
  | { name: 'order-confirmation'; orderId: string }
  | { name: 'login' }
  | { name: 'admin' };

interface NavbarProps {
  currentRoute: AppRoute;
  cartCount: number;
  searchQuery: string;
  onSearchChange: (value: string) => void;
  onNavigate: (route: AppRoute) => void;
  onOpenCart: () => void;
}

export function Navbar({
  currentRoute,
  cartCount,
  searchQuery,
  onSearchChange,
  onNavigate,
  onOpenCart,
}: NavbarProps) {
  const [searchOpen, setSearchOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems: { label: string; route: AppRoute; key: string }[] = [
    { label: 'Home', route: { name: 'home' }, key: 'home' },
    { label: 'Shop', route: { name: 'shop' }, key: 'shop' },
    { label: 'New Arrivals', route: { name: 'new-arrivals' }, key: 'new-arrivals' },
    { label: 'Collections', route: { name: 'collections' }, key: 'collections' },
    { label: 'Contact', route: { name: 'contact' }, key: 'contact' },
  ];

  const handleNavClick = (route: AppRoute) => {
    setMobileMenuOpen(false);
    onNavigate(route);
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (currentRoute.name !== 'shop' && currentRoute.name !== 'home') {
      onNavigate({ name: 'shop' });
    } else if (currentRoute.name === 'home') {
      const el = document.getElementById('catalog-section');
      el?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="sticky top-0 z-40 bg-[#FFFCFD]/95 backdrop-blur-md border-b border-[#EADCE1]">
      {/* Slim Announcement Bar */}
      <div className="bg-[#7A1C3A] text-[#FFFCFD] px-4 py-1.5 text-xs">
        <div className="max-w-[1200px] mx-auto flex items-center justify-center sm:justify-between gap-4">
          <p className="truncate font-medium tracking-wide">
            {BUSINESS_INFO.deliveryNote} · Latest Collections · Free delivery over NPR 3,500
          </p>
          <span className="hidden sm:inline text-[11px] text-[#DFCFA8] whitespace-nowrap shrink-0">
            Butwal, Nepal
          </span>
        </div>
      </div>

      {/* Main 3-Zone Header */}
      <header className="max-w-[1200px] mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4 md:gap-8">
        {/* Zone 1: Brand Wordmark */}
        <a
          href="/"
          onClick={(e) => {
            e.preventDefault();
            handleNavClick({ name: 'home' });
          }}
          className="flex items-center gap-2.5 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#7A1C3A] rounded-sm"
        >
          <BrandEmblem className="w-8 h-8 shrink-0" />
          <span className="font-display text-xl sm:text-2xl font-semibold tracking-tight text-[#1F1619]">
            {BUSINESS_INFO.shortName}
          </span>
        </a>

        {/* Zone 2: Primary Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-6 lg:gap-7" aria-label="Primary navigation">
          {navItems.map((item) => {
            const isActive = currentRoute.name === item.route.name;
            return (
              <a
                key={item.key}
                href={`/${item.key === 'home' ? '' : item.key}`}
                onClick={(e) => {
                  e.preventDefault();
                  handleNavClick(item.route);
                }}
                className={`text-sm font-medium whitespace-nowrap shrink-0 py-1 border-b transition-colors duration-150 ${
                  isActive
                    ? 'text-[#7A1C3A] border-[#7A1C3A]'
                    : 'text-[#645359] border-transparent hover:text-[#1F1619] hover:border-[#EED5DE]'
                }`}
              >
                {item.label}
              </a>
            );
          })}
        </nav>

        {/* Zone 3: Actions (Search + Cart Bag + Mobile Menu Toggle) */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          <button
            type="button"
            onClick={() => setSearchOpen((prev) => !prev)}
            aria-label={searchOpen ? 'Close search bar' : 'Search products'}
            aria-expanded={searchOpen}
            className="w-10 h-10 inline-flex items-center justify-center rounded-md text-[#1F1619] hover:bg-[#FDF5F7] transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-[#7A1C3A]"
          >
            {searchOpen ? <X className="w-4 h-4" /> : <Search className="w-4 h-4" />}
          </button>

          <button
            type="button"
            onClick={onOpenCart}
            aria-label={`Open shopping bag with ${cartCount} items`}
            className="inline-flex items-center gap-2 px-3.5 sm:px-4 py-2 rounded-md bg-[#7A1C3A] hover:bg-[#5C122A] text-white text-xs sm:text-sm font-medium whitespace-nowrap shrink-0 transition-colors cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#7A1C3A]"
          >
            <ShoppingBag className="w-4 h-4" />
            <span>Bag</span>
            <span className="tabular-nums font-semibold">({cartCount})</span>
          </button>

          <button
            type="button"
            onClick={() => setMobileMenuOpen((prev) => !prev)}
            aria-label={mobileMenuOpen ? 'Close navigation menu' : 'Open navigation menu'}
            aria-expanded={mobileMenuOpen}
            className="md:hidden w-10 h-10 inline-flex items-center justify-center rounded-md text-[#1F1619] hover:bg-[#FDF5F7] transition-colors cursor-pointer"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </header>

      {/* Expandable Search Bar */}
      {searchOpen && (
        <div className="border-t border-[#EADCE1] bg-[#FDF5F7] px-4 sm:px-6 py-3">
          <form onSubmit={handleSearchSubmit} className="max-w-[1200px] mx-auto flex items-center gap-3">
            <label htmlFor="header-product-search" className="sr-only">
              Search women&apos;s clothing
            </label>
            <input
              id="header-product-search"
              type="search"
              value={searchQuery}
              onChange={(e) => {
                onSearchChange(e.target.value);
                if (currentRoute.name !== 'shop' && currentRoute.name !== 'home') {
                  onNavigate({ name: 'shop' });
                }
              }}
              placeholder="Search dresses, kurtas, blouses, sarees..."
              autoFocus
              className="flex-1 bg-white border border-[#EADCE1] rounded-md px-3.5 py-2 text-sm text-[#1F1619] placeholder:text-[#645359]/70 focus:outline-none focus:border-[#7A1C3A]"
            />
            <button
              type="submit"
              className="px-4 py-2 rounded-md bg-[#1F1619] text-white text-xs font-medium hover:bg-[#7A1C3A] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Find Styles
            </button>
          </form>
        </div>
      )}

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <nav
          aria-label="Mobile navigation"
          className="md:hidden border-t border-[#EADCE1] bg-[#FFFCFD] px-4 py-4 space-y-1"
        >
          {navItems.map((item) => {
            const isActive = currentRoute.name === item.route.name;
            return (
              <a
                key={item.key}
                href={`/${item.key === 'home' ? '' : item.key}`}
                onClick={(e) => {
                  e.preventDefault();
                  handleNavClick(item.route);
                }}
                className={`block px-3 py-2.5 rounded-md text-sm font-medium transition-colors ${
                  isActive
                    ? 'bg-[#F8E8EE] text-[#7A1C3A]'
                    : 'text-[#1F1619] hover:bg-[#FDF5F7]'
                }`}
              >
                {item.label}
              </a>
            );
          })}
        </nav>
      )}
    </div>
  );
}
