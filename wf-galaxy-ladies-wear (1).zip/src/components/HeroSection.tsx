import React from 'react';
import { ArrowRight, MessageCircle } from 'lucide-react';
import { BUSINESS_INFO } from '../data/seedProducts';
import { buildWhatsAppUrl } from '../utils/commerce';
import { ProductImage } from './BrandLogo';

interface HeroSectionProps {
  onShopCollection: () => void;
  onExploreNewArrivals: () => void;
}

export function HeroSection({ onShopCollection, onExploreNewArrivals }: HeroSectionProps) {
  const whatsappUrl = buildWhatsAppUrl(
    'Hello WF Galaxy Ladies Wear! I would like to explore your latest collection.',
  );

  return (
    <section className="bg-gradient-to-b from-[#FDF5F7] to-[#FFFCFD] border-b border-[#EADCE1]">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-10 lg:py-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch">
          {/* Left Editorial Column */}
          <div className="lg:col-span-6 flex flex-col justify-center py-2 lg:py-6">
            <p className="text-xs sm:text-sm font-medium text-[#7A1C3A] tracking-wide mb-4">
              {BUSINESS_INFO.location} · {BUSINESS_INFO.tagline}
            </p>

            <h1
              className="font-display text-4xl sm:text-5xl lg:text-[3.5rem] font-semibold text-[#1F1619] leading-[1.08] tracking-tight max-w-xl"
              style={{ textWrap: 'balance' }}
            >
              Discover Your Style, Define Your Confidence.
            </h1>

            <p className="mt-5 text-base sm:text-lg text-[#645359] leading-relaxed max-w-lg">
              Explore the latest women&apos;s fashion at affordable prices. Find your perfect look
              with {BUSINESS_INFO.name}.
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-3.5">
              <button
                type="button"
                onClick={onShopCollection}
                className="inline-flex items-center gap-2.5 px-6 py-3 rounded-md bg-[#7A1C3A] hover:bg-[#5C122A] text-white text-sm font-medium transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#7A1C3A]"
              >
                <span>Shop Collection</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={onExploreNewArrivals}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-md border border-[#1F1619]/20 bg-white hover:border-[#7A1C3A] hover:text-[#7A1C3A] text-[#1F1619] text-sm font-medium transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer"
              >
                Explore New Arrivals
              </button>
            </div>

            <div className="mt-10 pt-6 border-t border-[#EADCE1] flex flex-wrap items-center gap-x-4 sm:gap-x-6 gap-y-2 text-xs text-[#645359]">
              <span>Quality</span>
              <span aria-hidden="true">·</span>
              <span>Affordable</span>
              <span aria-hidden="true">·</span>
              <span>Latest Collection</span>
              <span aria-hidden="true" className="hidden sm:inline">·</span>
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-[#7A1C3A] font-medium hover:underline basis-full sm:basis-auto"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                Order via WhatsApp
              </a>
            </div>
          </div>

          {/* Right Fashion Model Editorial Portrait */}
          <div className="lg:col-span-6">
            <div className="relative h-full min-h-[340px] sm:min-h-[420px] lg:min-h-[500px] rounded-lg overflow-hidden border border-[#EADCE1] bg-[#F8E8EE]">
              <ProductImage
                src="/images/hero_fashion_editorial_1795602446627.jpg"
                alt="Fashion model wearing an elegant deep burgundy silk wrap dress from WF Galaxy Ladies Wear in Butwal, Nepal"
                className="w-full h-full object-cover object-top"
                label="WF Galaxy Ladies Wear"
              />
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-[#1F1619]/92 via-[#1F1619]/55 to-transparent p-5 sm:p-6 pt-12">
                <p className="text-xs text-[#EBD9B4] font-medium">
                  Signature Burgundy Edit · Delivery Across Nepal
                </p>
                <p className="font-display text-xl sm:text-2xl text-white font-medium mt-0.5">
                  Rhea Burgundy Silk Wrap Maxi
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
