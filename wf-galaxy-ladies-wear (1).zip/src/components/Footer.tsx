import React from 'react';
import { MapPin, MessageCircle, Truck } from 'lucide-react';
import { BUSINESS_INFO } from '../data/seedProducts';
import { buildWhatsAppUrl } from '../utils/commerce';
import { BrandEmblem } from './BrandLogo';
import { AppRoute } from './Navbar';

interface FooterProps {
  onNavigate: (route: AppRoute) => void;
}

export function Footer({ onNavigate }: FooterProps) {
  const whatsappUrl = buildWhatsAppUrl(
    'Hello WF Galaxy Ladies Wear! I would like to inquire about your latest women\'s collection.',
  );

  return (
    <footer className="bg-[#1F1619] text-[#FFFCFD] border-t border-[#3A282E]">
      <div className="max-w-[1200px] mx-auto px-4 sm:px-6 py-14 grid grid-cols-1 md:grid-cols-4 gap-10">
        {/* Brand Summary */}
        <div className="md:col-span-2 space-y-4">
          <div className="flex items-center gap-3">
            <BrandEmblem className="w-10 h-10 shrink-0" />
            <div>
              <h2 className="font-display text-2xl font-semibold text-white">
                {BUSINESS_INFO.name}
              </h2>
              <p className="text-xs text-[#DFCFA8] tracking-wide">
                {BUSINESS_INFO.tagline}
              </p>
            </div>
          </div>
          <p className="text-sm text-[#D6C5CB] max-w-md leading-relaxed">
            Women&apos;s clothing boutique in Butwal offering quality, affordable dresses,
            traditional wear, party gowns, and everyday styles with delivery across Nepal.
          </p>
          <div className="flex flex-wrap items-center gap-4 text-xs text-[#E8D8DE] pt-1">
            <span className="inline-flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-[#DFCFA8]" />
              {BUSINESS_INFO.location}
            </span>
            <span className="inline-flex items-center gap-1.5">
              <Truck className="w-3.5 h-3.5 text-[#DFCFA8]" />
              {BUSINESS_INFO.deliveryNote}
            </span>
          </div>
        </div>

        {/* Navigation Links */}
        <div>
          <h3 className="text-xs font-semibold tracking-wider text-[#DFCFA8] mb-4">
            Store Navigation
          </h3>
          <ul className="space-y-2.5 text-sm text-[#D6C5CB]">
            {[
              { label: 'Home', route: { name: 'home' } as AppRoute },
              { label: 'Shop All Styles', route: { name: 'shop' } as AppRoute },
              { label: 'New Arrivals', route: { name: 'new-arrivals' } as AppRoute },
              { label: 'Collections', route: { name: 'collections' } as AppRoute },
              { label: 'Contact & Butwal Info', route: { name: 'contact' } as AppRoute },
            ].map((link) => (
              <li key={link.label}>
                <a
                  href={`/${link.route.name === 'home' ? '' : link.route.name}`}
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate(link.route);
                  }}
                  className="hover:text-white transition-colors"
                >
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
        </div>

        {/* Ordering & WhatsApp */}
        <div className="space-y-4">
          <h3 className="text-xs font-semibold tracking-wider text-[#DFCFA8]">
            Order &amp; Inquiries
          </h3>
          <p className="text-sm text-[#D6C5CB]">
            WhatsApp: <span className="text-white font-medium">{BUSINESS_INFO.whatsappDisplay}</span>
          </p>
          <p className="text-xs text-[#B9A3AB] leading-relaxed">
            Online orders and WhatsApp inquiries welcome. Cash on delivery available across
            Butwal and major cities in Nepal.
          </p>
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-md bg-[#7A1C3A] hover:bg-[#9B2C4E] text-white text-xs font-medium transition-colors"
          >
            <MessageCircle className="w-4 h-4" />
            Chat on WhatsApp
          </a>
        </div>
      </div>

      <div className="border-t border-[#342329] px-4 sm:px-6 py-5">
        <div className="max-w-[1200px] mx-auto flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-[#A9939B]">
          <p>
            &copy; {new Date().getFullYear()} {BUSINESS_INFO.name} · {BUSINESS_INFO.location}
          </p>
          <p>Quality · Affordable · Latest Collection</p>
        </div>
      </div>
    </footer>
  );
}
