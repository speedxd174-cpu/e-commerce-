import React, { useState } from 'react';
import { ArrowLeft, CheckCircle2, MessageCircle, ShieldCheck, Truck } from 'lucide-react';
import { BUSINESS_INFO } from '../data/seedProducts';
import {
  CartItem,
  CheckoutFormData,
  CheckoutValidationErrors,
  Order,
} from '../types/store';
import {
  buildOrderWhatsAppMessage,
  buildWhatsAppUrl,
  calculateCartTotals,
  formatNPR,
  generateOrderId,
  validateCheckoutForm,
} from '../utils/commerce';
import { ProductImage } from './BrandLogo';

const POPULAR_CITIES = [
  'Butwal, Rupandehi',
  'Bhairahawa, Rupandehi',
  'Kathmandu',
  'Lalitpur',
  'Pokhara, Kaski',
  'Bharatpur, Chitwan',
  'Tilottama, Rupandehi',
];

interface CheckoutPageProps {
  items: CartItem[];
  onSubmitOrder: (order: Order) => void;
  onBackToShop: () => void;
}

export function CheckoutPage({ items, onSubmitOrder, onBackToShop }: CheckoutPageProps) {
  const [formData, setFormData] = useState<CheckoutFormData>({
    customerName: '',
    phoneNumber: '',
    deliveryAddress: '',
    cityDistrict: '',
    instructions: '',
  });
  const [errors, setErrors] = useState<CheckoutValidationErrors>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const totals = calculateCartTotals(items);

  const handleFieldChange = (field: keyof CheckoutFormData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: undefined }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (items.length === 0) return;

    const validationErrors = validateCheckoutForm(formData);
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    setIsSubmitting(true);
    const newOrder: Order = {
      id: generateOrderId(),
      createdAt: new Date().toISOString(),
      customerName: formData.customerName.trim(),
      phoneNumber: formData.phoneNumber.trim(),
      deliveryAddress: formData.deliveryAddress.trim(),
      cityDistrict: formData.cityDistrict.trim(),
      instructions: formData.instructions.trim(),
      items: items.map((item) => ({
        productId: item.productId,
        productName: item.name,
        priceNpr: item.priceNpr,
        selectedSize: item.selectedSize,
        selectedColor: item.selectedColor.name,
        quantity: item.quantity,
        lineTotalNpr: item.priceNpr * item.quantity,
        imageUrl: item.imageUrl,
      })),
      subtotalNpr: totals.subtotalNpr,
      deliveryFeeNpr: totals.deliveryFeeNpr,
      totalNpr: totals.totalNpr,
      status: 'pending',
    };

    window.setTimeout(() => {
      setIsSubmitting(false);
      onSubmitOrder(newOrder);
    }, 250);
  };

  if (items.length === 0) {
    return (
      <main className="max-w-[900px] mx-auto px-4 sm:px-6 py-16 text-center">
        <h1 className="font-display text-3xl sm:text-4xl font-semibold text-[#1F1619]">
          Your shopping bag is empty
        </h1>
        <p className="text-sm text-[#645359] mt-3 max-w-md mx-auto">
          Select a dress, kurta, top, or outfit from our collection before proceeding to checkout.
        </p>
        <button
          type="button"
          onClick={onBackToShop}
          className="mt-6 inline-flex items-center gap-2 px-6 py-3 rounded-md bg-[#7A1C3A] text-white text-sm font-medium hover:bg-[#5C122A] transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Browse Collection</span>
        </button>
      </main>
    );
  }

  return (
    <main className="max-w-[1200px] mx-auto px-4 sm:px-6 py-10 sm:py-14">
      <button
        type="button"
        onClick={onBackToShop}
        className="inline-flex items-center gap-2 text-sm font-medium text-[#645359] hover:text-[#7A1C3A] mb-6 cursor-pointer"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Continue Shopping</span>
      </button>

      <div className="mb-8">
        <p className="text-xs font-medium text-[#7A1C3A] tracking-wide mb-1">
          {BUSINESS_INFO.name} · {BUSINESS_INFO.deliveryNote}
        </p>
        <h1 className="font-display text-3xl sm:text-4xl font-semibold text-[#1F1619]">
          Checkout &amp; Delivery Details
        </h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-start">
        {/* Left: Customer Delivery Form */}
        <form
          onSubmit={handleSubmit}
          noValidate
          className="lg:col-span-7 bg-white border border-[#EADCE1] rounded-lg p-6 sm:p-8 space-y-5"
        >
          <h2 className="font-display text-2xl font-semibold text-[#1F1619]">
            Customer &amp; Shipping Information
          </h2>

          <div>
            <label htmlFor="checkout-name" className="block text-xs font-semibold text-[#1F1619] mb-1.5">
              Customer Full Name <span className="text-[#7A1C3A]">*</span>
            </label>
            <input
              id="checkout-name"
              type="text"
              required
              value={formData.customerName}
              onChange={(e) => handleFieldChange('customerName', e.target.value)}
              placeholder="e.g., Prakriti Shrestha"
              aria-invalid={Boolean(errors.customerName)}
              className="w-full px-3.5 py-2.5 rounded-md border border-[#EADCE1] text-sm text-[#1F1619] focus:outline-none focus:border-[#7A1C3A]"
            />
            {errors.customerName && (
              <p role="alert" className="mt-1 text-xs text-[#B91C1C]">
                {errors.customerName}
              </p>
            )}
          </div>

          <div>
            <label htmlFor="checkout-phone" className="block text-xs font-semibold text-[#1F1619] mb-1.5">
              Phone Number (Nepal) <span className="text-[#7A1C3A]">*</span>
            </label>
            <input
              id="checkout-phone"
              type="tel"
              required
              value={formData.phoneNumber}
              onChange={(e) => handleFieldChange('phoneNumber', e.target.value)}
              placeholder="e.g., 9847012345 or +977 976-7740629"
              aria-invalid={Boolean(errors.phoneNumber)}
              className="w-full px-3.5 py-2.5 rounded-md border border-[#EADCE1] text-sm text-[#1F1619] focus:outline-none focus:border-[#7A1C3A]"
            />
            {errors.phoneNumber && (
              <p role="alert" className="mt-1 text-xs text-[#B91C1C]">
                {errors.phoneNumber}
              </p>
            )}
          </div>

          <div>
            <label htmlFor="checkout-address" className="block text-xs font-semibold text-[#1F1619] mb-1.5">
              Complete Delivery Address (Tole / Street / Landmark) <span className="text-[#7A1C3A]">*</span>
            </label>
            <input
              id="checkout-address"
              type="text"
              required
              value={formData.deliveryAddress}
              onChange={(e) => handleFieldChange('deliveryAddress', e.target.value)}
              placeholder="e.g., Amarpath, Ward 4, Near Horizon Chowk"
              aria-invalid={Boolean(errors.deliveryAddress)}
              className="w-full px-3.5 py-2.5 rounded-md border border-[#EADCE1] text-sm text-[#1F1619] focus:outline-none focus:border-[#7A1C3A]"
            />
            {errors.deliveryAddress && (
              <p role="alert" className="mt-1 text-xs text-[#B91C1C]">
                {errors.deliveryAddress}
              </p>
            )}
          </div>

          <div>
            <label htmlFor="checkout-city" className="block text-xs font-semibold text-[#1F1619] mb-1.5">
              City or District <span className="text-[#7A1C3A]">*</span>
            </label>
            <input
              id="checkout-city"
              type="text"
              required
              value={formData.cityDistrict}
              onChange={(e) => handleFieldChange('cityDistrict', e.target.value)}
              placeholder="e.g., Butwal, Rupandehi"
              aria-invalid={Boolean(errors.cityDistrict)}
              className="w-full px-3.5 py-2.5 rounded-md border border-[#EADCE1] text-sm text-[#1F1619] focus:outline-none focus:border-[#7A1C3A]"
            />
            <div className="flex flex-wrap gap-1.5 mt-2">
              {POPULAR_CITIES.map((city) => (
                <button
                  key={city}
                  type="button"
                  onClick={() => handleFieldChange('cityDistrict', city)}
                  className="px-2.5 py-1 rounded text-[11px] bg-[#FDF5F7] text-[#645359] hover:text-[#7A1C3A] hover:bg-[#F8E8EE] transition-colors cursor-pointer"
                >
                  {city}
                </button>
              ))}
            </div>
            {errors.cityDistrict && (
              <p role="alert" className="mt-1 text-xs text-[#B91C1C]">
                {errors.cityDistrict}
              </p>
            )}
          </div>

          <div>
            <label htmlFor="checkout-notes" className="block text-xs font-semibold text-[#1F1619] mb-1.5">
              Additional Instructions (Optional)
            </label>
            <textarea
              id="checkout-notes"
              rows={3}
              value={formData.instructions}
              onChange={(e) => handleFieldChange('instructions', e.target.value)}
              placeholder="Preferred delivery time, gift note, or fit preference..."
              className="w-full px-3.5 py-2.5 rounded-md border border-[#EADCE1] text-sm text-[#1F1619] focus:outline-none focus:border-[#7A1C3A]"
            />
          </div>

          <div className="p-4 rounded-md bg-[#FDF5F7] border border-[#EADCE1] text-xs text-[#645359] flex items-start gap-2.5">
            <ShieldCheck className="w-4 h-4 text-[#7A1C3A] shrink-0 mt-0.5" />
            <p>
              <strong className="text-[#1F1619]">Cash on Delivery &amp; WhatsApp Confirmation:</strong>{' '}
              Your order is saved immediately and our Butwal team confirms dispatch via phone or
              WhatsApp ({BUSINESS_INFO.whatsappDisplay}).
            </p>
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-4 px-6 rounded-md bg-[#7A1C3A] hover:bg-[#5C122A] disabled:opacity-60 text-white text-sm font-semibold tracking-wide transition-colors cursor-pointer"
          >
            {isSubmitting ? 'SUBMITTING ORDER...' : `PLACE ORDER · ${formatNPR(totals.totalNpr)}`}
          </button>
        </form>

        {/* Right: Order Summary */}
        <aside className="lg:col-span-5 bg-white border border-[#EADCE1] rounded-lg p-6 sm:p-7 space-y-5 lg:sticky lg:top-24">
          <h2 className="font-display text-2xl font-semibold text-[#1F1619]">
            Order Summary ({totals.itemCount})
          </h2>

          <div className="space-y-4 max-h-[360px] overflow-y-auto pr-1">
            {items.map((item) => (
              <div key={item.key} className="flex gap-3 pb-3.5 border-b border-[#EADCE1] last:border-b-0">
                <div className="w-16 h-20 rounded-md overflow-hidden border border-[#EADCE1] bg-[#FDF5F7] shrink-0">
                  <ProductImage
                    src={item.imageUrl}
                    alt={item.name}
                    className="w-full h-full object-cover object-top"
                    label={item.name}
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-sm font-semibold text-[#1F1619] truncate">{item.name}</h3>
                  <p className="text-xs text-[#645359] mt-0.5">
                    Size: {item.selectedSize} · Color: {item.selectedColor.name}
                  </p>
                  <div className="flex items-center justify-between mt-2 text-xs">
                    <span className="text-[#645359] tabular-nums">Qty: {item.quantity}</span>
                    <span className="font-semibold text-[#1F1619] tabular-nums">
                      {formatNPR(item.priceNpr * item.quantity)}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="pt-4 border-t border-[#EADCE1] space-y-2 text-sm">
            <div className="flex justify-between text-[#645359]">
              <span>Subtotal</span>
              <span className="tabular-nums font-medium text-[#1F1619]">
                {formatNPR(totals.subtotalNpr)}
              </span>
            </div>
            <div className="flex justify-between text-[#645359]">
              <span>Delivery Fee (Across Nepal)</span>
              <span className="tabular-nums font-medium text-[#1F1619]">
                {totals.deliveryFeeNpr === 0 ? 'Free' : formatNPR(totals.deliveryFeeNpr)}
              </span>
            </div>
            <div className="flex justify-between text-base font-semibold text-[#1F1619] pt-3 border-t border-[#EADCE1]">
              <span>Total Amount</span>
              <span className="tabular-nums text-[#7A1C3A]">{formatNPR(totals.totalNpr)}</span>
            </div>
          </div>

          <div className="pt-2 text-xs text-[#645359] flex items-center gap-2">
            <Truck className="w-4 h-4 text-[#7A1C3A] shrink-0" />
            <span>Free delivery on orders NPR 3,500 and above across Nepal.</span>
          </div>
        </aside>
      </div>
    </main>
  );
}

interface OrderConfirmationViewProps {
  order: Order | undefined;
  onContinueShopping: () => void;
}

export function OrderConfirmationView({
  order,
  onContinueShopping,
}: OrderConfirmationViewProps) {
  if (!order) {
    return (
      <main className="max-w-[760px] mx-auto px-4 sm:px-6 py-16 text-center">
        <h1 className="font-display text-3xl font-semibold text-[#1F1619]">Order not found</h1>
        <p className="text-sm text-[#645359] mt-2">
          This order record is not present in browser storage.
        </p>
        <button
          type="button"
          onClick={onContinueShopping}
          className="mt-6 px-6 py-3 rounded-md bg-[#7A1C3A] text-white text-sm font-medium cursor-pointer"
        >
          Back to Storefront
        </button>
      </main>
    );
  }

  const whatsappConfirmUrl = buildWhatsAppUrl(buildOrderWhatsAppMessage(order));

  return (
    <main className="max-w-[820px] mx-auto px-4 sm:px-6 py-12 sm:py-16">
      <div className="bg-white border border-[#EADCE1] rounded-lg p-6 sm:p-10 space-y-6">
        <div className="flex items-start gap-4 pb-6 border-b border-[#EADCE1]">
          <CheckCircle2 className="w-9 h-9 text-[#15803D] shrink-0 mt-0.5" />
          <div>
            <p className="text-xs font-medium text-[#7A1C3A]">
              Order Saved · {BUSINESS_INFO.name}
            </p>
            <h1 className="font-display text-3xl sm:text-4xl font-semibold text-[#1F1619] mt-1">
              Thank You, {order.customerName}!
            </h1>
            <p className="text-sm text-[#645359] mt-1.5">
              Your order has been recorded with unique Order ID{' '}
              <span className="font-mono font-semibold text-[#1F1619]">{order.id}</span>.
            </p>
          </div>
        </div>

        {/* Customer & Delivery Details */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 text-sm bg-[#FDF5F7] border border-[#EADCE1] rounded-md p-5">
          <div>
            <p className="text-xs font-semibold text-[#645359]">Customer</p>
            <p className="font-medium text-[#1F1619] mt-1">{order.customerName}</p>
            <p className="text-[#645359] tabular-nums">{order.phoneNumber}</p>
          </div>
          <div>
            <p className="text-xs font-semibold text-[#645359]">Delivery Address</p>
            <p className="font-medium text-[#1F1619] mt-1">{order.deliveryAddress}</p>
            <p className="text-[#645359]">{order.cityDistrict}</p>
          </div>
          {order.instructions && (
            <div className="sm:col-span-2 pt-2 border-t border-[#EADCE1]">
              <p className="text-xs font-semibold text-[#645359]">Instructions</p>
              <p className="text-[#1F1619] mt-0.5">{order.instructions}</p>
            </div>
          )}
        </div>

        {/* Ordered Items */}
        <div className="space-y-3">
          <h2 className="text-sm font-semibold text-[#1F1619]">Ordered Items</h2>
          <div className="divide-y divide-[#EADCE1] border border-[#EADCE1] rounded-md">
            {order.items.map((item, idx) => (
              <div key={`${item.productId}-${idx}`} className="p-4 flex items-center justify-between gap-4">
                <div>
                  <p className="text-sm font-medium text-[#1F1619]">{item.productName}</p>
                  <p className="text-xs text-[#645359] mt-0.5">
                    Size: {item.selectedSize} · Color: {item.selectedColor} · Qty: {item.quantity}
                  </p>
                </div>
                <span className="text-sm font-semibold text-[#1F1619] tabular-nums">
                  {formatNPR(item.lineTotalNpr)}
                </span>
              </div>
            ))}
          </div>

          <div className="flex items-center justify-between pt-3 text-base font-semibold text-[#1F1619]">
            <span>Total Payable</span>
            <span className="tabular-nums text-[#7A1C3A]">{formatNPR(order.totalNpr)}</span>
          </div>
        </div>

        {/* Actions */}
        <div className="pt-4 border-t border-[#EADCE1] flex flex-wrap items-center gap-3">
          <a
            href={whatsappConfirmUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-5 py-3 rounded-md bg-[#7A1C3A] hover:bg-[#5C122A] text-white text-sm font-medium transition-colors"
          >
            <MessageCircle className="w-4 h-4" />
            <span>Send Order Details on WhatsApp</span>
          </a>

          <button
            type="button"
            onClick={onContinueShopping}
            className="px-5 py-3 rounded-md border border-[#EADCE1] text-sm font-medium text-[#1F1619] hover:border-[#7A1C3A] hover:text-[#7A1C3A] transition-colors cursor-pointer"
          >
            Continue Shopping
          </button>
        </div>
      </div>
    </main>
  );
}
