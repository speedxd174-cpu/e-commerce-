import React, { useMemo, useState } from 'react';
import {
  ArrowLeft,
  Database,
  Edit3,
  LogOut,
  MessageCircle,
  Package,
  Plus,
  RotateCcw,
  Search,
  ShoppingBag,
  Trash2,
  X,
} from 'lucide-react';
import { CATEGORIES, GALLERY_PRESET_IMAGES } from '../data/seedProducts';
import {
  Order,
  OrderStatus,
  Product,
  ProductCategory,
  ProductColor,
} from '../types/store';
import {
  buildAdminCustomerWhatsAppMessage,
  buildWhatsAppUrl,
  computeOrderMetrics,
  formatNPR,
} from '../utils/commerce';
import { ProductImage } from './BrandLogo';

interface AdminDashboardProps {
  products: Product[];
  orders: Order[];
  onUpdateOrderStatus: (orderId: string, status: OrderStatus) => void;
  onUpsertProduct: (product: Product) => void;
  onDeleteProduct: (productId: string) => void;
  onResetDemoData: () => void;
  onBackToStore: () => void;
  onLogout: () => void;
}

const STATUS_OPTIONS: OrderStatus[] = [
  'pending',
  'confirmed',
  'processing',
  'shipped',
  'completed',
];

const STATUS_LABELS: Record<OrderStatus, string> = {
  pending: 'Pending',
  confirmed: 'Confirmed',
  processing: 'Processing',
  shipped: 'Shipped',
  completed: 'Completed',
};

const STATUS_STYLES: Record<OrderStatus, string> = {
  pending: 'bg-[#FEF3C7] text-[#92400E] border-[#FDE68A]',
  confirmed: 'bg-[#E0F2FE] text-[#075985] border-[#BAE6FD]',
  processing: 'bg-[#F3E8FF] text-[#6B21A8] border-[#E9D5FF]',
  shipped: 'bg-[#F8E8EE] text-[#7A1C3A] border-[#EED5DE]',
  completed: 'bg-[#DCFCE7] text-[#166534] border-[#BBF7D0]',
};

const ALL_SIZES = ['XS', 'S', 'M', 'L', 'XL', 'XXL', 'Free Size'];

export function AdminDashboard({
  products,
  orders,
  onUpdateOrderStatus,
  onUpsertProduct,
  onDeleteProduct,
  onResetDemoData,
  onBackToStore,
  onLogout,
}: AdminDashboardProps) {
  const [activeTab, setActiveTab] = useState<'orders' | 'products'>('orders');
  const [orderStatusFilter, setOrderStatusFilter] = useState<'all' | OrderStatus>('all');
  const [orderSearch, setOrderSearch] = useState('');
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isProductFormOpen, setIsProductFormOpen] = useState(false);

  const metrics = useMemo(() => computeOrderMetrics(orders), [orders]);

  const filteredOrders = useMemo(() => {
    const q = orderSearch.trim().toLowerCase();
    return orders.filter((order) => {
      if (orderStatusFilter !== 'all' && order.status !== orderStatusFilter) {
        return false;
      }
      if (!q) return true;
      return (
        order.id.toLowerCase().includes(q) ||
        order.customerName.toLowerCase().includes(q) ||
        order.phoneNumber.toLowerCase().includes(q) ||
        order.cityDistrict.toLowerCase().includes(q)
      );
    });
  }, [orders, orderStatusFilter, orderSearch]);

  const openNewProductForm = () => {
    setEditingProduct({
      id: `wfg-prod-${Date.now()}`,
      name: '',
      category: "Women's Dresses",
      priceNpr: 2500,
      description: '',
      fabricCare: 'Premium breathable fabric · Gentle hand wash',
      imageUrl: GALLERY_PRESET_IMAGES[0].url,
      imageAlt: "Women's clothing item from WF Galaxy Ladies Wear Butwal",
      sizes: ['S', 'M', 'L'],
      colors: [
        { name: 'Burgundy', hex: '#7A1C3A' },
        { name: 'Soft Blush', hex: '#E8B8C6' },
      ],
      isNewArrival: true,
      isFeatured: true,
      inStock: true,
      createdAt: new Date().toISOString(),
    });
    setIsProductFormOpen(true);
  };

  const openEditProductForm = (product: Product) => {
    setEditingProduct({ ...product });
    setIsProductFormOpen(true);
  };

  return (
    <main className="max-w-[1200px] mx-auto px-4 sm:px-6 py-8 sm:py-12 space-y-8">
      {/* Header & Storefront Return */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <button
            type="button"
            onClick={onBackToStore}
            className="inline-flex items-center gap-1.5 text-xs font-medium text-[#645359] hover:text-[#7A1C3A] mb-2 cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Storefront</span>
          </button>
          <h1 className="font-display text-3xl sm:text-4xl font-semibold text-[#1F1619]">
            Owner Admin Dashboard
          </h1>
          <p className="text-sm text-[#645359] mt-1">
            Manage customer orders, update fulfillment status, and edit your WF Galaxy catalog.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            onClick={onResetDemoData}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-md border border-[#EADCE1] bg-white hover:border-[#7A1C3A] text-xs font-medium text-[#1F1619] transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Demo Data</span>
          </button>

          <button
            type="button"
            onClick={openNewProductForm}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-md bg-[#7A1C3A] hover:bg-[#5C122A] text-white text-xs font-medium transition-colors cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Product</span>
          </button>

          <button
            type="button"
            onClick={onLogout}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-md border border-[#EADCE1] bg-white hover:border-[#7A1C3A] hover:text-[#7A1C3A] text-xs font-medium text-[#1F1619] transition-colors cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Lock &amp; Sign Out</span>
          </button>
        </div>
      </div>

      {/* Browser Demo Storage Notice */}
      <div className="rounded-lg border border-[#EADCE1] bg-[#FDF5F7] px-4 py-3.5 flex items-start gap-3 text-xs text-[#645359]">
        <Database className="w-4 h-4 text-[#7A1C3A] shrink-0 mt-0.5" />
        <p className="leading-relaxed">
          <strong className="text-[#1F1619]">Demo Browser Storage Active:</strong> Orders and
          catalog edits persist in your browser&apos;s <code className="font-mono">localStorage</code>{' '}
          for this client presentation—not yet a shared multi-device cloud database. The data layer
          uses a clean repository interface ready for Supabase or Firebase integration.
        </p>
      </div>

      {/* Overview KPI Strip */}
      <section aria-label="Store overview metrics" className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-[#EADCE1] rounded-lg p-5">
          <p className="text-xs font-medium text-[#645359]">Total Orders</p>
          <p className="mt-2 text-2xl sm:text-3xl font-semibold text-[#1F1619] tabular-nums">
            {metrics.totalOrders}
          </p>
        </div>
        <div className="bg-white border border-[#EADCE1] rounded-lg p-5">
          <p className="text-xs font-medium text-[#645359]">Pending Orders</p>
          <p className="mt-2 text-2xl sm:text-3xl font-semibold text-[#B45309] tabular-nums">
            {metrics.pendingOrders}
          </p>
        </div>
        <div className="bg-white border border-[#EADCE1] rounded-lg p-5">
          <p className="text-xs font-medium text-[#645359]">Completed Orders</p>
          <p className="mt-2 text-2xl sm:text-3xl font-semibold text-[#15803D] tabular-nums">
            {metrics.completedOrders}
          </p>
        </div>
        <div className="bg-white border border-[#EADCE1] rounded-lg p-5">
          <p className="text-xs font-medium text-[#645359]">Total Order Value</p>
          <p className="mt-2 text-2xl sm:text-3xl font-semibold text-[#7A1C3A] tabular-nums">
            {formatNPR(metrics.totalOrderValueNpr)}
          </p>
        </div>
      </section>

      {/* Main Dashboard Tabs */}
      <div className="flex items-center gap-2 border-b border-[#EADCE1]">
        <button
          type="button"
          onClick={() => setActiveTab('orders')}
          className={`inline-flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition-colors cursor-pointer ${
            activeTab === 'orders'
              ? 'border-[#7A1C3A] text-[#7A1C3A]'
              : 'border-transparent text-[#645359] hover:text-[#1F1619]'
          }`}
        >
          <ShoppingBag className="w-4 h-4" />
          <span>Orders ({orders.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('products')}
          className={`inline-flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition-colors cursor-pointer ${
            activeTab === 'products'
              ? 'border-[#7A1C3A] text-[#7A1C3A]'
              : 'border-transparent text-[#645359] hover:text-[#1F1619]'
          }`}
        >
          <Package className="w-4 h-4" />
          <span>Products ({products.length})</span>
        </button>
      </div>

      {/* ORDERS TAB */}
      {activeTab === 'orders' && (
        <section className="space-y-5">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
              {(['all', ...STATUS_OPTIONS] as const).map((status) => (
                <button
                  key={status}
                  type="button"
                  onClick={() => setOrderStatusFilter(status)}
                  className={`px-3 py-1.5 rounded-md text-xs font-medium whitespace-nowrap shrink-0 cursor-pointer transition-colors ${
                    orderStatusFilter === status
                      ? 'bg-[#7A1C3A] text-white'
                      : 'bg-[#FDF5F7] text-[#645359] hover:text-[#1F1619]'
                  }`}
                >
                  {status === 'all' ? 'All Orders' : STATUS_LABELS[status]}
                </button>
              ))}
            </div>

            <div className="relative sm:w-72">
              <Search className="w-4 h-4 text-[#645359] absolute left-3 top-1/2 -translate-y-1/2" />
              <label htmlFor="admin-order-search" className="sr-only">
                Search orders
              </label>
              <input
                id="admin-order-search"
                type="search"
                value={orderSearch}
                onChange={(e) => setOrderSearch(e.target.value)}
                placeholder="Search order ID, customer, phone..."
                className="w-full pl-9 pr-3 py-2 bg-white border border-[#EADCE1] rounded-md text-xs text-[#1F1619] focus:outline-none focus:border-[#7A1C3A]"
              />
            </div>
          </div>

          {filteredOrders.length === 0 ? (
            <div className="p-12 text-center bg-white border border-[#EADCE1] rounded-lg">
              <p className="font-display text-2xl font-semibold text-[#1F1619]">No orders match</p>
              <p className="text-sm text-[#645359] mt-1">
                Place a test order from the storefront or clear your status/search filters.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredOrders.map((order) => {
                const whatsappCustomerUrl = buildWhatsAppUrl(
                  buildAdminCustomerWhatsAppMessage(order),
                  order.phoneNumber,
                );
                const formattedDate = new Date(order.createdAt).toLocaleString('en-US', {
                  month: 'short',
                  day: 'numeric',
                  year: 'numeric',
                  hour: 'numeric',
                  minute: '2-digit',
                });

                return (
                  <article
                    key={order.id}
                    className="bg-white border border-[#EADCE1] rounded-lg p-5 sm:p-6 space-y-4"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-[#EADCE1]">
                      <div>
                        <div className="flex flex-wrap items-center gap-2.5">
                          <span className="font-mono text-sm font-semibold text-[#1F1619]">
                            {order.id}
                          </span>
                          <span
                            className={`px-2 py-0.5 rounded text-[11px] font-medium border ${STATUS_STYLES[order.status]}`}
                          >
                            {STATUS_LABELS[order.status]}
                          </span>
                        </div>
                        <p className="text-xs text-[#645359] mt-1 tabular-nums">{formattedDate}</p>
                      </div>

                      <div className="flex flex-wrap items-center gap-2.5">
                        <label htmlFor={`status-${order.id}`} className="sr-only">
                          Order status for {order.id}
                        </label>
                        <select
                          id={`status-${order.id}`}
                          value={order.status}
                          onChange={(e) =>
                            onUpdateOrderStatus(order.id, e.target.value as OrderStatus)
                          }
                          className="bg-[#FDF5F7] border border-[#EADCE1] rounded-md px-3 py-2 text-xs font-medium text-[#1F1619] focus:outline-none focus:border-[#7A1C3A] cursor-pointer"
                        >
                          {STATUS_OPTIONS.map((statusOption) => (
                            <option key={statusOption} value={statusOption}>
                              Status: {STATUS_LABELS[statusOption]}
                            </option>
                          ))}
                        </select>

                        <a
                          href={whatsappCustomerUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md bg-[#7A1C3A] hover:bg-[#5C122A] text-white text-xs font-medium transition-colors"
                        >
                          <MessageCircle className="w-3.5 h-3.5" />
                          <span>WhatsApp Customer</span>
                        </a>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-12 gap-5 text-sm">
                      <div className="md:col-span-4 space-y-1">
                        <p className="text-xs font-semibold text-[#645359]">Customer &amp; Delivery</p>
                        <p className="font-semibold text-[#1F1619]">{order.customerName}</p>
                        <p className="text-xs text-[#1F1619] tabular-nums">{order.phoneNumber}</p>
                        <p className="text-xs text-[#645359]">
                          {order.deliveryAddress}, {order.cityDistrict}
                        </p>
                        {order.instructions && (
                          <p className="text-xs text-[#7A1C3A] pt-1">Note: {order.instructions}</p>
                        )}
                      </div>

                      <div className="md:col-span-6 space-y-2">
                        <p className="text-xs font-semibold text-[#645359]">Ordered Products</p>
                        <ul className="space-y-1.5">
                          {order.items.map((item, idx) => (
                            <li
                              key={`${order.id}-item-${idx}`}
                              className="text-xs text-[#1F1619] flex items-center justify-between gap-2"
                            >
                              <span>
                                <strong>{item.productName}</strong> ({item.selectedSize},{' '}
                                {item.selectedColor}) &times; {item.quantity}
                              </span>
                              <span className="tabular-nums text-[#645359]">
                                {formatNPR(item.lineTotalNpr)}
                              </span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="md:col-span-2 md:text-right">
                        <p className="text-xs font-semibold text-[#645359]">Total Price</p>
                        <p className="text-lg font-semibold text-[#7A1C3A] tabular-nums mt-1">
                          {formatNPR(order.totalNpr)}
                        </p>
                        <p className="text-[11px] text-[#645359] tabular-nums">
                          {order.deliveryFeeNpr === 0
                            ? 'Free Delivery'
                            : `Incl. ${formatNPR(order.deliveryFeeNpr)} delivery`}
                        </p>
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          )}
        </section>
      )}

      {/* PRODUCTS TAB */}
      {activeTab === 'products' && (
        <section className="bg-white border border-[#EADCE1] rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-[#EADCE1] bg-[#FDF5F7] text-xs font-semibold text-[#645359]">
                  <th className="py-3.5 px-4">Product</th>
                  <th className="py-3.5 px-4">Category</th>
                  <th className="py-3.5 px-4">Price</th>
                  <th className="py-3.5 px-4">Sizes</th>
                  <th className="py-3.5 px-4">Colors</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#EADCE1] text-sm">
                {products.map((product) => (
                  <tr key={product.id} className="hover:bg-[#FDF5F7]/60">
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-3">
                        <div className="w-11 h-14 rounded overflow-hidden border border-[#EADCE1] shrink-0 bg-[#FDF5F7]">
                          <ProductImage
                            src={product.imageUrl}
                            alt={product.name}
                            className="w-full h-full object-cover object-top"
                            label={product.name}
                          />
                        </div>
                        <div className="min-w-0">
                          <p className="font-semibold text-[#1F1619] truncate max-w-[220px]">
                            {product.name}
                          </p>
                          <p className="text-xs text-[#645359] truncate max-w-[220px]">
                            {product.inStock ? 'In Stock' : 'Out of Stock'}
                            {product.isNewArrival ? ' · New Arrival' : ''}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-xs text-[#645359] whitespace-nowrap">
                      {product.category}
                    </td>
                    <td className="py-3.5 px-4 font-semibold text-[#7A1C3A] tabular-nums whitespace-nowrap">
                      {formatNPR(product.priceNpr)}
                    </td>
                    <td className="py-3.5 px-4 text-xs text-[#645359]">
                      {product.sizes.join(', ')}
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-1.5">
                        {product.colors.map((c) => (
                          <span
                            key={c.name}
                            title={c.name}
                            className="w-3.5 h-3.5 rounded-full border border-black/15"
                            style={{ backgroundColor: c.hex }}
                          />
                        ))}
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-right whitespace-nowrap">
                      <div className="inline-flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => openEditProductForm(product)}
                          aria-label={`Edit ${product.name}`}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded border border-[#EADCE1] text-xs font-medium text-[#1F1619] hover:border-[#7A1C3A] hover:text-[#7A1C3A] cursor-pointer"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                          <span>Edit</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => onDeleteProduct(product.id)}
                          aria-label={`Delete ${product.name}`}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded border border-[#EADCE1] text-xs font-medium text-[#B91C1C] hover:bg-[#FEF2F2] cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Delete</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {/* Product Add/Edit Modal */}
      {isProductFormOpen && editingProduct && (
        <ProductEditorModal
          product={editingProduct}
          onClose={() => {
            setIsProductFormOpen(false);
            setEditingProduct(null);
          }}
          onSave={(saved) => {
            onUpsertProduct(saved);
            setIsProductFormOpen(false);
            setEditingProduct(null);
          }}
        />
      )}
    </main>
  );
}

interface ProductEditorModalProps {
  product: Product;
  onClose: () => void;
  onSave: (product: Product) => void;
}

function ProductEditorModal({ product, onClose, onSave }: ProductEditorModalProps) {
  const [name, setName] = useState(product.name);
  const [category, setCategory] = useState<ProductCategory>(product.category);
  const [priceNpr, setPriceNpr] = useState(String(product.priceNpr));
  const [description, setDescription] = useState(product.description);
  const [fabricCare, setFabricCare] = useState(product.fabricCare);
  const [imageUrl, setImageUrl] = useState(product.imageUrl);
  const [sizes, setSizes] = useState<string[]>(product.sizes);
  const [colorsText, setColorsText] = useState(
    product.colors.map((c) => `${c.name}:${c.hex}`).join(', '),
  );
  const [isNewArrival, setIsNewArrival] = useState(product.isNewArrival);
  const [inStock, setInStock] = useState(product.inStock);
  const [error, setError] = useState('');

  const toggleSize = (size: string) => {
    setSizes((prev) =>
      prev.includes(size) ? prev.filter((s) => s !== size) : [...prev, size],
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numericPrice = Number(priceNpr);
    if (!name.trim()) {
      setError('Product name is required.');
      return;
    }
    if (!Number.isFinite(numericPrice) || numericPrice <= 0) {
      setError('Enter a valid price in NPR.');
      return;
    }
    if (sizes.length === 0) {
      setError('Select at least one available size.');
      return;
    }

    const parsedColors: ProductColor[] = colorsText
      .split(',')
      .map((entry) => entry.trim())
      .filter(Boolean)
      .map((entry) => {
        const [colorName, hex] = entry.split(':').map((s) => s.trim());
        return {
          name: colorName || 'Burgundy',
          hex: hex && /^#[0-9A-Fa-f]{3,6}$/.test(hex) ? hex : '#7A1C3A',
        };
      });

    onSave({
      ...product,
      name: name.trim(),
      category,
      priceNpr: Math.round(numericPrice),
      description:
        description.trim() || 'Refined ladies wear piece curated by WF Galaxy in Butwal.',
      fabricCare: fabricCare.trim() || 'Gentle hand wash',
      imageUrl: imageUrl.trim() || GALLERY_PRESET_IMAGES[0].url,
      imageAlt: `${name.trim()} — ${category} at WF Galaxy Ladies Wear, Butwal, Nepal`,
      sizes,
      colors: parsedColors.length > 0 ? parsedColors : [{ name: 'Burgundy', hex: '#7A1C3A' }],
      isNewArrival,
      inStock,
    });
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-[#1F1619]/50 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-label={product.name ? `Edit ${product.name}` : 'Add new product'}
    >
      <div className="bg-[#FFFCFD] border border-[#EADCE1] rounded-lg max-w-2xl w-full max-h-[92vh] overflow-y-auto p-6 sm:p-8 shadow-xl">
        <div className="flex items-center justify-between pb-4 border-b border-[#EADCE1]">
          <h2 className="font-display text-2xl font-semibold text-[#1F1619]">
            {product.name ? 'Edit Product' : 'Add New Product'}
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close product editor"
            className="w-9 h-9 inline-flex items-center justify-center rounded-md hover:bg-[#FDF5F7] cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          {error && (
            <p role="alert" className="p-3 rounded bg-[#FEF2F2] text-xs text-[#B91C1C]">
              {error}
            </p>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="prod-name" className="block text-xs font-semibold text-[#1F1619] mb-1">
                Product Name
              </label>
              <input
                id="prod-name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g., Rose Silk Festive Kurti"
                className="w-full px-3 py-2 border border-[#EADCE1] rounded-md text-sm bg-white focus:outline-none focus:border-[#7A1C3A]"
              />
            </div>

            <div>
              <label htmlFor="prod-cat" className="block text-xs font-semibold text-[#1F1619] mb-1">
                Category
              </label>
              <select
                id="prod-cat"
                value={category}
                onChange={(e) => setCategory(e.target.value as ProductCategory)}
                className="w-full px-3 py-2 border border-[#EADCE1] rounded-md text-sm bg-white focus:outline-none focus:border-[#7A1C3A]"
              >
                {CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="prod-price" className="block text-xs font-semibold text-[#1F1619] mb-1">
                Price (NPR)
              </label>
              <input
                id="prod-price"
                type="number"
                min={100}
                step={50}
                value={priceNpr}
                onChange={(e) => setPriceNpr(e.target.value)}
                className="w-full px-3 py-2 border border-[#EADCE1] rounded-md text-sm bg-white tabular-nums focus:outline-none focus:border-[#7A1C3A]"
              />
            </div>

            <div>
              <label htmlFor="prod-preset-img" className="block text-xs font-semibold text-[#1F1619] mb-1">
                Studio Image Preset
              </label>
              <select
                id="prod-preset-img"
                value={
                  GALLERY_PRESET_IMAGES.some((p) => p.url === imageUrl) ? imageUrl : ''
                }
                onChange={(e) => {
                  if (e.target.value) setImageUrl(e.target.value);
                }}
                className="w-full px-3 py-2 border border-[#EADCE1] rounded-md text-sm bg-white focus:outline-none focus:border-[#7A1C3A]"
              >
                <option value="">Custom Image URL</option>
                {GALLERY_PRESET_IMAGES.map((img) => (
                  <option key={img.url} value={img.url}>
                    {img.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label htmlFor="prod-img-url" className="block text-xs font-semibold text-[#1F1619] mb-1">
              Product Image URL
            </label>
            <input
              id="prod-img-url"
              type="text"
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              className="w-full px-3 py-2 border border-[#EADCE1] rounded-md text-xs font-mono bg-white focus:outline-none focus:border-[#7A1C3A]"
            />
          </div>

          <div>
            <label htmlFor="prod-desc" className="block text-xs font-semibold text-[#1F1619] mb-1">
              Description
            </label>
            <textarea
              id="prod-desc"
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3 py-2 border border-[#EADCE1] rounded-md text-sm bg-white focus:outline-none focus:border-[#7A1C3A]"
            />
          </div>

          <div>
            <label htmlFor="prod-care" className="block text-xs font-semibold text-[#1F1619] mb-1">
              Fabric &amp; Care
            </label>
            <input
              id="prod-care"
              type="text"
              value={fabricCare}
              onChange={(e) => setFabricCare(e.target.value)}
              className="w-full px-3 py-2 border border-[#EADCE1] rounded-md text-sm bg-white focus:outline-none focus:border-[#7A1C3A]"
            />
          </div>

          <div>
            <span className="block text-xs font-semibold text-[#1F1619] mb-1.5">
              Available Sizes
            </span>
            <div className="flex flex-wrap gap-2">
              {ALL_SIZES.map((s) => {
                const active = sizes.includes(s);
                return (
                  <button
                    key={s}
                    type="button"
                    onClick={() => toggleSize(s)}
                    className={`px-3 py-1.5 rounded text-xs font-medium border cursor-pointer ${
                      active
                        ? 'bg-[#7A1C3A] border-[#7A1C3A] text-white'
                        : 'bg-white border-[#EADCE1] text-[#1F1619]'
                    }`}
                  >
                    {s}
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <label htmlFor="prod-colors" className="block text-xs font-semibold text-[#1F1619] mb-1">
              Colors (Format: Name:#HEX, comma-separated)
            </label>
            <input
              id="prod-colors"
              type="text"
              value={colorsText}
              onChange={(e) => setColorsText(e.target.value)}
              placeholder="Deep Burgundy:#7A1C3A, Soft Blush:#E8B8C6"
              className="w-full px-3 py-2 border border-[#EADCE1] rounded-md text-xs font-mono bg-white focus:outline-none focus:border-[#7A1C3A]"
            />
          </div>

          <div className="flex flex-wrap items-center gap-6 pt-1 text-xs font-medium text-[#1F1619]">
            <label className="inline-flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={isNewArrival}
                onChange={(e) => setIsNewArrival(e.target.checked)}
                className="accent-[#7A1C3A]"
              />
              <span>Mark as New Arrival</span>
            </label>
            <label className="inline-flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={inStock}
                onChange={(e) => setInStock(e.target.checked)}
                className="accent-[#7A1C3A]"
              />
              <span>In Stock</span>
            </label>
          </div>

          <div className="pt-4 border-t border-[#EADCE1] flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-md border border-[#EADCE1] text-xs font-medium text-[#1F1619] hover:bg-[#FDF5F7] cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-md bg-[#7A1C3A] hover:bg-[#5C122A] text-white text-xs font-medium cursor-pointer"
            >
              Save Product
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
