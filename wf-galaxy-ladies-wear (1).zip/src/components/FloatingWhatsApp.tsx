import React from 'react';
import { MessageCircle } from 'lucide-react';
import { BUSINESS_INFO } from '../data/seedProducts';
import { buildWhatsAppUrl } from '../utils/commerce';

export function FloatingWhatsApp() {
  const url = buildWhatsAppUrl(
    `Hello ${BUSINESS_INFO.name}! I have a question about your ladies wear collection.`,
  );

  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={`Contact ${BUSINESS_INFO.name} on WhatsApp (${BUSINESS_INFO.whatsappDisplay})`}
      className="fixed bottom-5 right-5 z-30 inline-flex items-center gap-2 px-4 py-3 rounded-full bg-[#15803D] hover:bg-[#166534] text-white text-xs sm:text-sm font-medium shadow-lg transition-transform duration-150 hover:-translate-y-0.5 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#15803D]"
    >
      <MessageCircle className="w-4 h-4 shrink-0" />
      <span className="hidden sm:inline">WhatsApp</span>
    </a>
  );
}
