import React, { useEffect, useState } from 'react';
import { ArrowLeft, Eye, EyeOff, KeyRound, Lock } from 'lucide-react';
import { BUSINESS_INFO } from '../data/seedProducts';
import { BrandEmblem } from './BrandLogo';

type AuthMode = 'loading' | 'setup' | 'env' | 'claimed';

interface AdminLoginPageProps {
  onAuthenticated: (token: string) => void;
  onBackToStore: () => void;
}

export function AdminLoginPage({ onAuthenticated, onBackToStore }: AdminLoginPageProps) {
  const [mode, setMode] = useState<AuthMode>('loading');
  const [accessCode, setAccessCode] = useState('');
  const [confirmCode, setConfirmCode] = useState('');
  const [showCode, setShowCode] = useState(false);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    let cancelled = false;
    fetch('/api/admin/auth/status')
      .then(async (res) => {
        if (!res.ok) throw new Error('Could not check owner access status');
        return (await res.json()) as { mode: 'env' | 'setup' | 'claimed' };
      })
      .then((data) => {
        if (!cancelled) {
          setMode(data.mode);
        }
      })
      .catch(() => {
        if (!cancelled) {
          setMode('env');
          setError('Unable to reach authentication server. Please refresh and try again.');
        }
      });

    return () => {
      cancelled = true;
    };
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const trimmed = accessCode.trim();
    if (trimmed.length < 4) {
      setError('Special access code must be at least 4 characters.');
      return;
    }

    if (mode === 'setup' && trimmed !== confirmCode.trim()) {
      setError('Access codes do not match. Please confirm your code.');
      return;
    }

    setSubmitting(true);
    try {
      const endpoint = mode === 'setup' ? '/api/admin/auth/setup' : '/api/admin/auth/login';
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: trimmed }),
      });
      const data = (await res.json()) as { token?: string; error?: string };

      if (!res.ok || !data.token) {
        setError(data.error || 'Access denied. Please verify your special code.');
        if (res.status === 409) {
          setMode('claimed');
        }
        return;
      }

      onAuthenticated(data.token);
    } catch {
      setError('Connection error while verifying your access code.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <main className="min-h-[75vh] flex items-center justify-center px-4 sm:px-6 py-12 bg-gradient-to-b from-[#FDF5F7] to-[#FFFCFD]">
      <div className="w-full max-w-md bg-white border border-[#EADCE1] rounded-lg p-7 sm:p-9 shadow-sm space-y-6">
        <div className="flex items-center justify-between">
          <button
            type="button"
            onClick={onBackToStore}
            className="inline-flex items-center gap-1.5 text-xs font-medium text-[#645359] hover:text-[#7A1C3A] cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Store</span>
          </button>
          <BrandEmblem className="w-8 h-8" />
        </div>

        <div className="space-y-1.5">
          <div className="inline-flex items-center gap-1.5 text-xs font-medium text-[#7A1C3A]">
            {mode === 'setup' ? (
              <KeyRound className="w-3.5 h-3.5" />
            ) : (
              <Lock className="w-3.5 h-3.5" />
            )}
            <span>{BUSINESS_INFO.name} · Private Access</span>
          </div>

          <h1 className="font-display text-3xl font-semibold text-[#1F1619]">
            {mode === 'setup' ? 'Set Owner Access Code' : 'Owner Sign In'}
          </h1>

          <p className="text-sm text-[#645359] leading-relaxed">
            {mode === 'setup'
              ? 'Create your private special code to lock the admin dashboard. Only someone with this code can open it.'
              : 'Enter your special access code to open the WF Galaxy Admin Dashboard.'}
          </p>
        </div>

        {mode === 'loading' ? (
          <div className="py-8 text-center text-xs text-[#645359]">
            Checking access configuration...
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4" noValidate>
            {error && (
              <p
                role="alert"
                className="p-3 rounded-md bg-[#FEF2F2] border border-[#FECACA] text-xs text-[#B91C1C]"
              >
                {error}
              </p>
            )}

            <div>
              <label
                htmlFor="owner-access-code"
                className="block text-xs font-semibold text-[#1F1619] mb-1.5"
              >
                Special Access Code
              </label>
              <div className="relative">
                <input
                  id="owner-access-code"
                  type={showCode ? 'text' : 'password'}
                  autoComplete="current-password"
                  autoFocus
                  value={accessCode}
                  onChange={(e) => setAccessCode(e.target.value)}
                  placeholder="Enter special code..."
                  className="w-full pl-3.5 pr-10 py-2.5 rounded-md border border-[#EADCE1] text-sm text-[#1F1619] bg-white focus:outline-none focus:border-[#7A1C3A]"
                />
                <button
                  type="button"
                  onClick={() => setShowCode((prev) => !prev)}
                  aria-label={showCode ? 'Hide access code' : 'Show access code'}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#645359] hover:text-[#1F1619] p-1 cursor-pointer"
                >
                  {showCode ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {mode === 'setup' && (
              <div>
                <label
                  htmlFor="owner-confirm-code"
                  className="block text-xs font-semibold text-[#1F1619] mb-1.5"
                >
                  Confirm Special Access Code
                </label>
                <input
                  id="owner-confirm-code"
                  type={showCode ? 'text' : 'password'}
                  autoComplete="new-password"
                  value={confirmCode}
                  onChange={(e) => setConfirmCode(e.target.value)}
                  placeholder="Re-enter special code..."
                  className="w-full px-3.5 py-2.5 rounded-md border border-[#EADCE1] text-sm text-[#1F1619] bg-white focus:outline-none focus:border-[#7A1C3A]"
                />
              </div>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="w-full py-3 px-5 rounded-md bg-[#7A1C3A] hover:bg-[#5C122A] disabled:opacity-60 text-white text-sm font-medium transition-colors cursor-pointer"
            >
              {submitting
                ? 'Verifying...'
                : mode === 'setup'
                  ? 'Save Special Code & Open Admin'
                  : 'Unlock Admin Dashboard'}
            </button>
          </form>
        )}
      </div>
    </main>
  );
}
